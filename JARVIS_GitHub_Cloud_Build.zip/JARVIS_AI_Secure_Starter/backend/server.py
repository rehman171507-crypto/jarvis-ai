import os
import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="JARVIS private AI bridge")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
MODEL = os.environ.get("OPENAI_MODEL", "gpt-6.2-astra")

class AskRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/ask")
def ask(body: AskRequest):
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=503, detail="Server administrator has not configured the AI key.")
    try:
        response = requests.post(
            "https://api.openai.com/v1/responses",
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"},
            json={
                "model": MODEL,
                "instructions": "You are JARVIS, a helpful and privacy-conscious assistant. Reply in the language used by the user (Urdu or English). Keep answers clear and concise.",
                "input": body.message,
                "store": False
            },
            timeout=45,
        )
        if response.status_code >= 400:
            raise HTTPException(status_code=502, detail="AI provider returned an error. Check server configuration and API access.")
        data = response.json()
        parts = []
        for item in data.get("output", []):
            if item.get("type") == "message":
                for content in item.get("content", []):
                    if content.get("type") == "output_text":
                        parts.append(content.get("text", ""))
        answer = "\n".join(p for p in parts if p).strip()
        return {"answer": answer or "I could not create an answer. Please try again."}
    except requests.RequestException:
        raise HTTPException(status_code=502, detail="Could not connect to the AI provider.")
