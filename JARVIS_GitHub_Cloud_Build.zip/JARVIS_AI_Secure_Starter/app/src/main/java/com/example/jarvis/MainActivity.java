package com.example.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 101, REQ_MIC = 102;
    // Replace this with your own HTTPS backend address after deployment.
    private static final String BACKEND_URL = "https://YOUR-HTTPS-BACKEND.example/ask";
    private TextView status;
    private TextToSpeech tts;
    private final ExecutorService network = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildScreen();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("en", "US"));
        });
    }

    private int dp(int v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24)); root.setBackgroundColor(Color.rgb(7,17,31));
        TextView title = new TextView(this); title.setText("J.A.R.V.I.S"); title.setTextColor(Color.rgb(0,217,255));
        title.setTextSize(34); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(70)));
        TextView sub = new TextView(this); sub.setText("SECURE AI VOICE ASSISTANT"); sub.setTextColor(Color.LTGRAY); sub.setTextSize(12); sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(40)));
        status = new TextView(this); status.setText("Ready. Tap below and speak Urdu or English."); status.setTextColor(Color.WHITE);
        status.setTextSize(17); status.setGravity(Gravity.CENTER); status.setPadding(dp(8), dp(24), dp(8), dp(24));
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(190)));
        Button talk = new Button(this); talk.setText("TALK TO JARVIS"); talk.setTextSize(18); talk.setTextColor(Color.WHITE);
        talk.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(8,126,164)));
        root.addView(talk, new LinearLayout.LayoutParams(-1, dp(60))); talk.setOnClickListener(v -> startListening());
        TextView note = new TextView(this); note.setText("Internet AI needs your private backend to be configured. Microphone works only after permission.");
        note.setTextColor(Color.GRAY); note.setTextSize(12); note.setGravity(Gravity.CENTER); note.setPadding(0, dp(24), 0, 0); root.addView(note);
        setContentView(root);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS");
            startActivityForResult(i, REQ_SPEECH); status.setText("Listening…");
        } catch (Exception e) { status.setText("Speech recognition is unavailable on this phone."); }
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_SPEECH && result == RESULT_OK && data != null) {
            ArrayList<String> a = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (a != null && !a.isEmpty()) askBackend(a.get(0)); else status.setText("I did not catch that. Try again.");
        }
    }

    private void askBackend(String question) {
        status.setText("You: " + question + "\n\nJARVIS is thinking…");
        if (BACKEND_URL.contains("YOUR-HTTPS-BACKEND")) {
            status.setText("Backend not configured yet. Follow README to connect your secure AI server.\n\nYou said: " + question);
            return;
        }
        network.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(BACKEND_URL).openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000);
                c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                JSONObject body = new JSONObject(); body.put("message", question);
                try (OutputStream out = c.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
                InputStream stream = (c.getResponseCode() >= 200 && c.getResponseCode() < 300) ? c.getInputStream() : c.getErrorStream();
                StringBuilder raw = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) { String line; while ((line = r.readLine()) != null) raw.append(line); }
                JSONObject json = new JSONObject(raw.toString());
                if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) throw new Exception(json.optString("detail", "Server error"));
                String answer = json.optString("answer", "No answer returned.");
                runOnUiThread(() -> { status.setText("You: " + question + "\n\nJARVIS: " + answer); speak(answer); });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Could not reach AI server. Check internet and backend URL.\n" + e.getMessage()));
            } finally { if (c != null) c.disconnect(); }
        });
    }

    private void speak(String text) {
        if (tts == null) return;
        // Prefer Urdu voice when the phone has one; otherwise use English fallback.
        int result = tts.setLanguage(new Locale("ur", "PK"));
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] g) {
        super.onRequestPermissionsResult(code, p, g);
        if (code == REQ_MIC && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else if (code == REQ_MIC) status.setText("Microphone permission is required to listen.");
    }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } network.shutdown(); super.onDestroy(); }
}
